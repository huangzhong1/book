package com.sxt.service;

import java.util.List;

import com.sxt.domain.Hotel;

public interface HotelService {

	List<Hotel> queryAll();

}
