package com.sxt.sys.service;

import java.util.List;

import com.sxt.sys.domain.Dept;
import com.sxt.sys.utils.DataGridView;
import com.sxt.sys.vo.DeptVo;

public interface DeptService {
	
	/**
	 * 查询所有的部门返回List<Dept>
	 */
	public List<Dept> queryAllDeptForList(DeptVo deptVo);
	
	/**
	 * 查询所有部门返回DataGridView
	 */
	public DataGridView queryAllDepts(DeptVo deptVo);

	/**
	 * 添加部门
	 * @param deptVo
	 */
	public void addDept(DeptVo deptVo);

	/**
	 * 根据ID查询部门
	 * @param id
	 * @return
	 */
	public Dept queryDeptById(Integer id);

	/**
	 * 修改部门信息
	 * @param deptVo
	 */
	public void updateDept(DeptVo deptVo);

	/**
	 * 删除
	 * @param deptVo
	 */
	public void deleteDept(Integer id);
	
}
