package com.sxt.sys.mapper;

import java.util.List;

import com.sxt.sys.domain.Role;

public interface RoleMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Role record);

    int insertSelective(Role record);

    Role selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Role record);

    int updateByPrimaryKey(Role record);
    
    List<Role> queryAllRoles(Role record);

    //根据roleid删除sys_role_permission里面的数据
	void deleteRolePermissionByRoleId(Integer roleId);
	//添加角色和权限之间的关系数据
	void addRolePermission(Integer roleId, Integer perId);

	/**
	 * 根据用户ID查询当前用户的角色
	 */
	List<Role> queryRolesByUserId(Integer id);
}