package com.sxt.sys.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sxt.sys.constast.SYS_Constast;
import com.sxt.sys.domain.Permission;
import com.sxt.sys.domain.User;
import com.sxt.sys.service.PermissionService;
import com.sxt.sys.utils.DataGridView;
import com.sxt.sys.utils.TreeNode;
import com.sxt.sys.utils.TreeNodeBuilder;
import com.sxt.sys.utils.ZTreeNode;
import com.sxt.sys.vo.PermissionVo;

/**
 *权限管理
 * @author LJH
 *
 */
@Controller
@RequestMapping("permission")
public class PermissionController {

	@Autowired
	private PermissionService permissionService;
	
	
	/**
	 * 加载index主页左边的导航树
	 */
	@RequestMapping("loadIndexTreeMeuns")
	@ResponseBody
	public List<TreeNode> loadIndexTreeMeuns(PermissionVo permissionVo,HttpSession session){
		//1,查询当前用户的所有权限  type=permission【先查询所有的】 
		List<TreeNode> nodes=new ArrayList<>();
		//得到当前登陆的用户
		User user=(User) session.getAttribute("user");
		List<Permission> permissions=null;
		if(user.getType()==SYS_Constast.USER_TYPE_SUPER) {
			permissionVo.setType(SYS_Constast.PERMISSION_TYPE_MENU);
			permissions=this.permissionService.queryAllPermissionForList(permissionVo);
		}else {
			//根据用户id查询菜单
			permissions=this.permissionService.queryPermissionByUserIdForList(user.getId(),SYS_Constast.PERMISSION_TYPE_MENU);
		}
		for (Permission p : permissions) {
			boolean spread=p.getSpread()==1?true:false;
			nodes.add(new TreeNode(p.getId(), p.getPid(), p.getName(), p.getHref(), p.getIcon(), spread));
		}
		//构造树的对象 
		return TreeNodeBuilder.build(nodes, 1);
	}
	
	
	/***权限管理开始*********/

	/**
	 * 跳转到permissionManager.jsp
	 */
	@RequestMapping("toPermissionManager")
	public String toPermissionManager() {
		return "system/permission/permissionManager";
	}
	
	/**
	 * 跳转到左边权限树
	 */
	@RequestMapping("toPermissionLeft")
	public String toPermissionLeft()
	{
		return "system/permission/permissionLeft";
	}
	
	/**
	 * 跳转到右边的权限列表
	 */
	@RequestMapping("toPermissionRight")
	public String toPermissionRight()
	{
		return "system/permission/permissionRight";
	}
	
	/**
	 * 加载左边的权限树
	 */
	@RequestMapping("loadPermissionLeftTree")
	@ResponseBody
	public List<ZTreeNode> loadPermissionLeftTree(PermissionVo permissionVo){
		List<ZTreeNode> nodes=new ArrayList<>();
		//查询所有的权限 type=permission
		permissionVo.setType(SYS_Constast.PERMISSION_TYPE_MENU);
		List<Permission> permissionForList = permissionService.queryAllPermissionForList(permissionVo);
		for (Permission d : permissionForList) {
			Boolean isParent=d.getParent()==1?true:false;
			Boolean open=d.getSpread()==1?true:false;
			nodes.add(new ZTreeNode(d.getId(), d.getPid(), d.getName(), isParent, open));
		}
		return nodes;
	}
	
	
	/**
	 * 加载权限列表
	 */
	@RequestMapping("loadAllPermissions")
	@ResponseBody
	public DataGridView loadAllPermissions(PermissionVo permissionVo) {
		//查询所有的权限 type=permission
		permissionVo.setType(SYS_Constast.PERMISSION_TYPE_PERMISSION);
		return this.permissionService.queryAllPermissions(permissionVo);
	}
	
	
	/**
	 * 跳转到添加页面
	 */
	@RequestMapping("toAddPermission")
	public String toAddPermission() {
		return "system/permission/permissionAdd";
	}
	
	/**
	 * 添加
	 */
	@RequestMapping("addPermission")
	@ResponseBody
	public Map<String,Object> addPermission(PermissionVo permissionVo){
		Map<String, Object> map=new HashMap<>();
		String msg="添加成功";
		try {
			//做添加
			this.permissionService.addPermission(permissionVo);
		} catch (Exception e) {
			msg="添加失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	/**
	 * 跳转到修改页面
	 */
	@RequestMapping("toUpdatePermission")
	public String toUpdatePermission(PermissionVo permissionVo,Model model) {
		Permission permission=this.permissionService.queryPermissionById(permissionVo.getId());
		//处理图标问题
		if(null!=permission.getIcon()) {
			permission.setIcon(permission.getIcon().replace("&", "&amp;"));
		}
		model.addAttribute("permission",permission);
		return "system/permission/permissionUpdate";
	}
	
	/**
	 * 修改
	 */
	@RequestMapping("updatePermission")
	@ResponseBody
	public Map<String,Object> updatePermission(PermissionVo permissionVo){
		Map<String, Object> map=new HashMap<>();
		String msg="修改成功";
		try {
			//做修改
			this.permissionService.updatePermission(permissionVo);
		} catch (Exception e) {
			msg="修改失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	/**
	 * 删除
	 */
	@RequestMapping("deletePermission")
	@ResponseBody
	public Map<String,Object> deletePermission(PermissionVo permissionVo){
		Map<String, Object> map=new HashMap<>();
		String msg="删除成功";
		try {
			//做删除
			this.permissionService.deletePermission(permissionVo.getId());
		} catch (Exception e) {
			msg="删除失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	/**
	 * 批量删除
	 */
	@RequestMapping("batchDeletePermission")
	@ResponseBody
	public Map<String,Object> batchDeletePermission(PermissionVo permissionVo){
		Map<String, Object> map=new HashMap<>();
		String msg="删除成功";
		try {
			//做删除
			Integer[] ids=permissionVo.getIds();
			if(null!=ids&&ids.length>0) {
				for (Integer integer : ids) {
					this.permissionService.deletePermission(integer);
				}
			}
		} catch (Exception e) {
			msg="删除失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	/***权限管理结束*********/
	
	
	
}
