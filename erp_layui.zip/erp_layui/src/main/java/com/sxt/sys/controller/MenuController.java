package com.sxt.sys.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sxt.sys.constast.SYS_Constast;
import com.sxt.sys.domain.Permission;
import com.sxt.sys.service.PermissionService;
import com.sxt.sys.utils.DataGridView;
import com.sxt.sys.utils.ZTreeNode;
import com.sxt.sys.vo.PermissionVo;

@Controller
@RequestMapping("menu")
public class MenuController {
	
	@Autowired
	private PermissionService permissionService;

	/**
	 * 跳转到menuManager.jsp
	 */
	@RequestMapping("toMenuManager")
	public String toMenuManager() {
		return "system/menu/menuManager";
	}
	
	/**
	 * 跳转到左边菜单树
	 */
	@RequestMapping("toMenuLeft")
	public String toMenuLeft()
	{
		return "system/menu/menuLeft";
	}
	
	/**
	 * 跳转到右边的菜单列表
	 */
	@RequestMapping("toMenuRight")
	public String toMenuRight()
	{
		return "system/menu/menuRight";
	}
	
	/**
	 * 加载左边的菜单树
	 */
	@RequestMapping("loadMenuLeftTree")
	@ResponseBody
	public List<ZTreeNode> loadMenuLeftTree(PermissionVo permissionVo){
		List<ZTreeNode> nodes=new ArrayList<>();
		//查询所有的菜单 type=menu
		permissionVo.setType(SYS_Constast.PERMISSION_TYPE_MENU);
		List<Permission> menuForList = permissionService.queryAllPermissionForList(permissionVo);
		for (Permission d : menuForList) {
			Boolean isParent=d.getParent()==1?true:false;
			Boolean open=d.getSpread()==1?true:false;
			nodes.add(new ZTreeNode(d.getId(), d.getPid(), d.getName(), isParent, open));
		}
		return nodes;
	}
	
	
	/**
	 * 加载菜单列表
	 */
	@RequestMapping("loadAllMenus")
	@ResponseBody
	public DataGridView loadAllMenus(PermissionVo permissionVo) {
		//查询所有的菜单 type=menu
		permissionVo.setType(SYS_Constast.PERMISSION_TYPE_MENU);
		return this.permissionService.queryAllPermissions(permissionVo);
	}
	
	
	/**
	 * 跳转到添加页面
	 */
	@RequestMapping("toAddMenu")
	public String toAddMenu() {
		return "system/menu/menuAdd";
	}
	
	/**
	 * 添加
	 */
	@RequestMapping("addMenu")
	@ResponseBody
	public Map<String,Object> addMenu(PermissionVo permissionVo){
		Map<String, Object> map=new HashMap<>();
		String msg="添加成功";
		try {
			//做添加
			this.permissionService.addPermission(permissionVo);
		} catch (Exception e) {
			msg="添加失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	/**
	 * 跳转到修改页面
	 */
	@RequestMapping("toUpdateMenu")
	public String toUpdateMenu(PermissionVo permissionVo,Model model) {
		Permission permission=this.permissionService.queryPermissionById(permissionVo.getId());
		//处理图标问题
		if(null!=permission.getIcon()) {
			permission.setIcon(permission.getIcon().replace("&", "&amp;"));
		}
		model.addAttribute("menu",permission);
		return "system/menu/menuUpdate";
	}
	
	/**
	 * 修改
	 */
	@RequestMapping("updateMenu")
	@ResponseBody
	public Map<String,Object> updateMenu(PermissionVo permissionVo){
		Map<String, Object> map=new HashMap<>();
		String msg="修改成功";
		try {
			//做修改
			this.permissionService.updatePermission(permissionVo);
		} catch (Exception e) {
			msg="修改失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	/**
	 * 删除
	 */
	@RequestMapping("deleteMenu")
	@ResponseBody
	public Map<String,Object> deleteMenu(PermissionVo permissionVo){
		Map<String, Object> map=new HashMap<>();
		String msg="删除成功";
		try {
			//做删除
			this.permissionService.deletePermission(permissionVo.getId());
		} catch (Exception e) {
			msg="删除失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	/**
	 * 批量删除
	 */
	@RequestMapping("batchDeleteMenu")
	@ResponseBody
	public Map<String,Object> batchDeleteMenu(PermissionVo permissionVo){
		Map<String, Object> map=new HashMap<>();
		String msg="删除成功";
		try {
			//做删除
			Integer[] ids=permissionVo.getIds();
			if(null!=ids&&ids.length>0) {
				for (Integer integer : ids) {
					this.permissionService.deletePermission(integer);
				}
			}
		} catch (Exception e) {
			msg="删除失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	
}
