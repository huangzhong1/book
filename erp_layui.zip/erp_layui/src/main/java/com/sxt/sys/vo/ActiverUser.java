package com.sxt.sys.vo;

import java.util.List;

import com.sxt.sys.domain.User;

public class ActiverUser {
	
	//当前用户
	private User currentUser;
	//当前用户的角色
	private List<String> roles;
	
	//当前用户的权限
	private List<String> permissions;

	public User getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(User currentUser) {
		this.currentUser = currentUser;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public List<String> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<String> permissions) {
		this.permissions = permissions;
	}

}
