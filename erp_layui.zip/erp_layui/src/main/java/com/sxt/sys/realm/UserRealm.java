package com.sxt.sys.realm;

import java.util.ArrayList;
import java.util.List;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;

import com.sxt.sys.constast.SYS_Constast;
import com.sxt.sys.domain.Permission;
import com.sxt.sys.domain.Role;
import com.sxt.sys.domain.User;
import com.sxt.sys.service.PermissionService;
import com.sxt.sys.service.RoleService;
import com.sxt.sys.service.UserService;
import com.sxt.sys.vo.ActiverUser;

/**
 * 用户认证和授权
 * 
 * @author LJH
 *
 */
public class UserRealm extends AuthorizingRealm {

	@Autowired
	private UserService userService;

	@Autowired
	private RoleService roleService;

	@Autowired
	private PermissionService permissionService;

	public String getName() {
		return this.getClass().getSimpleName();
	}

	/**
	 * 认证
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {

		// 得到用户登陆名
		String loginname = token.getPrincipal().toString();
		// 根据登陆名查询用户
		User user = this.userService.queryUserByLoginName(loginname);
		ActiverUser activerUser = new ActiverUser();
		if (null != user) {
			activerUser.setCurrentUser(user);
			// 把权限和角色放到activerUser里面
			List<String> roles = new ArrayList<>();
			// 当前用户的权限
			List<String> permissions = new ArrayList<>();
			List<Role> userRoles = new ArrayList<>();
			List<Permission> userPermissions = new ArrayList<>();
			if (user.getType() == SYS_Constast.USER_TYPE_NORMAL) {
				// 查询当前用户的角色
				userRoles = this.roleService.queryRolesByUserId(user.getId());
				// 查询当前用户的权限
				userPermissions = this.permissionService.queryPermissionByUserIdForList(user.getId(),
						SYS_Constast.PERMISSION_TYPE_PERMISSION);
				for (Role r : userRoles) {
					roles.add(r.getName());
				}
				for (Permission p : userPermissions) {
					permissions.add(p.getPercode());
				}
			} else {// 如果是内置用户 那么就不受权限控制可以看到所有的东西
				roles.add("*");
				permissions.add("*:*");
			}
			// 绑定到activerUser
			activerUser.setRoles(roles);
			activerUser.setPermissions(permissions);
			ByteSource salt = ByteSource.Util.bytes(user.getName() + user.getAddress());
			AuthenticationInfo info = new SimpleAuthenticationInfo(activerUser, user.getPwd(), salt, getName());
			return info;
		} else {
			// 用户不存在
			return null;
		}
	}

	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection collection) {
		ActiverUser activerUser = (ActiverUser) collection.getPrimaryPrincipal();
		List<String> roles = activerUser.getRoles();
		// 当前用户的权限
		List<String> permissions = activerUser.getPermissions();
		SimpleAuthorizationInfo authorizationInfo=new SimpleAuthorizationInfo();
		if(roles.size()>0) {
			authorizationInfo.addRoles(roles);
		}
		if(permissions.size()>0) {
			authorizationInfo.addStringPermissions(permissions);
		}
		return authorizationInfo;
	}

}
