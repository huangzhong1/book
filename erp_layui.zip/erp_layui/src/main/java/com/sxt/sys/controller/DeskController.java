package com.sxt.sys.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 工作台管理
 * @author LJH
 *
 */
@Controller
@RequestMapping("desk")
public class DeskController {
	
	
	/**
	 * 跳转到system/main/deskManager.jsp
	 */
	@RequestMapping("toDeskManager")
	public String toDeskManager() {
		return "system/main/deskManager";
	}

}
