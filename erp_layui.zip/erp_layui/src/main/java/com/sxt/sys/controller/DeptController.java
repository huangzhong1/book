package com.sxt.sys.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sxt.sys.domain.Dept;
import com.sxt.sys.service.DeptService;
import com.sxt.sys.utils.DataGridView;
import com.sxt.sys.utils.ZTreeNode;
import com.sxt.sys.vo.DeptVo;

@Controller
@RequestMapping("dept")
public class DeptController {
	
	@Autowired
	private DeptService deptService;

	/**
	 * 跳转到deptManager.jsp
	 */
	@RequestMapping("toDeptManager")
	public String toDeptManager() {
		return "system/dept/deptManager";
	}
	
	/**
	 * 跳转到左边部门树
	 */
	@RequestMapping("toDeptLeft")
	public String toDeptLeft()
	{
		return "system/dept/deptLeft";
	}
	
	/**
	 * 跳转到右边的部门列表
	 */
	@RequestMapping("toDeptRight")
	public String toDeptRight()
	{
		return "system/dept/deptRight";
	}
	
	/**
	 * 加载左边的部门树
	 */
	@RequestMapping("loadDeptLeftTree")
	@ResponseBody
	public List<ZTreeNode> loadDeptLeftTree(DeptVo deptVo){
		List<ZTreeNode> nodes=new ArrayList<>();
		//查询所有的部门
		List<Dept> deptForList = deptService.queryAllDeptForList(deptVo);
		for (Dept d : deptForList) {
			Boolean isParent=d.getParent()==1?true:false;
			Boolean open=d.getSpread()==1?true:false;
			nodes.add(new ZTreeNode(d.getId(), d.getPid(), d.getName(), isParent, open));
		}
		return nodes;
	}
	
	
	/**
	 * 加载部门列表
	 */
	@RequestMapping("loadAllDepts")
	@ResponseBody
	public DataGridView loadAllDepts(DeptVo deptVo) {
		return this.deptService.queryAllDepts(deptVo);
	}
	
	
	/**
	 * 跳转到添加页面
	 */
	@RequestMapping("toAddDept")
	public String toAddDept() {
		return "system/dept/deptAdd";
	}
	
	/**
	 * 添加
	 */
	@RequestMapping("addDept")
	@ResponseBody
	public Map<String,Object> addDept(DeptVo deptVo){
		Map<String, Object> map=new HashMap<>();
		String msg="添加成功";
		try {
			//做添加
			this.deptService.addDept(deptVo);
		} catch (Exception e) {
			msg="添加失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	/**
	 * 跳转到修改页面
	 */
	@RequestMapping("toUpdateDept")
	public String toUpdateDept(DeptVo deptVo,Model model) {
		Dept dept=this.deptService.queryDeptById(deptVo.getId());
		model.addAttribute("dept", dept);
		return "system/dept/deptUpdate";
	}
	
	/**
	 * 修改
	 */
	@RequestMapping("updateDept")
	@ResponseBody
	public Map<String,Object> updateDept(DeptVo deptVo){
		Map<String, Object> map=new HashMap<>();
		String msg="修改成功";
		try {
			//做修改
			this.deptService.updateDept(deptVo);
		} catch (Exception e) {
			msg="修改失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	/**
	 * 删除
	 */
	@RequestMapping("deleteDept")
	@ResponseBody
	public Map<String,Object> deleteDept(DeptVo deptVo){
		Map<String, Object> map=new HashMap<>();
		String msg="删除成功";
		try {
			//做删除
			this.deptService.deleteDept(deptVo.getId());
		} catch (Exception e) {
			msg="删除失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	/**
	 * 批量删除
	 */
	@RequestMapping("batchDeleteDept")
	@ResponseBody
	public Map<String,Object> batchDeleteDept(DeptVo deptVo){
		Map<String, Object> map=new HashMap<>();
		String msg="删除成功";
		try {
			//做删除
			Integer[] ids=deptVo.getIds();
			if(null!=ids&&ids.length>0) {
				for (Integer integer : ids) {
					this.deptService.deleteDept(integer);
				}
			}
		} catch (Exception e) {
			msg="删除失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	
}
