package com.sxt.sys.mapper;

import java.util.List;

import com.sxt.sys.domain.User;

public interface UserMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);
    /**
     * 根据登陆名查询用户
     */
    User queryUserByLoginName(String loginname);
    
    /**
     * 全查询过滤  系统内置用户 type<>0
     */
    List<User> queryAllUsers(User record);

    /**
     * 加载根据部门ID查询用户
     * @param deptid
     * @return
     */
	List<User> loadAllUserByDeptId(Integer deptid);

	//删除原有的用户的角色
	void deleteUserRoleByUserId(Integer uid);

	//保存用户的角色之间的关系
	void insertUserRole(Integer uid, Integer rid);
    
}