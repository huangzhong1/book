package com.sxt.sys.service;

import com.sxt.sys.domain.LogInfo;
import com.sxt.sys.utils.DataGridView;
import com.sxt.sys.vo.LogInfoVo;

public interface LogInfoService {
	
	
	/**
	 * 查询所有日志返回DataGridView
	 */
	public DataGridView queryAllLogInfos(LogInfoVo logInfoVo);

	/**
	 * 添加日志
	 * @param logInfoVo
	 */
	public void addLogInfo(LogInfoVo logInfoVo);

	/**
	 * 根据ID查询日志
	 * @param id
	 * @return
	 */
	public LogInfo queryLogInfoById(Integer id);

	/**
	 * 修改日志信息
	 * @param logInfoVo
	 */
	public void updateLogInfo(LogInfoVo logInfoVo);

	/**
	 * 删除
	 * @param logInfoVo
	 */
	public void deleteLogInfo(Integer id);
	
}
