package com.sxt.sys.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sxt.sys.service.LogInfoService;
import com.sxt.sys.utils.DataGridView;
import com.sxt.sys.vo.LogInfoVo;

@Controller
@RequestMapping("logInfo")
public class LogInfoController {
	
	@Autowired
	private LogInfoService logInfoService;

	/**
	 * 跳转到logInfoManager.jsp
	 */
	@RequestMapping("toLogInfoManager")
	public String toLogInfoManager() {
		return "system/logInfo/logInfoManager";
	}
	
	
	/**
	 * 加载日志列表
	 */
	@RequestMapping("loadAllLogInfos")
	@ResponseBody
	public DataGridView loadAllLogInfos(LogInfoVo logInfoVo) {
		return this.logInfoService.queryAllLogInfos(logInfoVo);
	}
	
	/**
	 * 删除
	 */
	@RequestMapping("deleteLogInfo")
	@ResponseBody
	public Map<String,Object> deleteLogInfo(LogInfoVo logInfoVo){
		Map<String, Object> map=new HashMap<>();
		String msg="删除成功";
		try {
			//做删除
			this.logInfoService.deleteLogInfo(logInfoVo.getId());
		} catch (Exception e) {
			msg="删除失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	/**
	 * 批量删除
	 */
	@RequestMapping("batchDeleteLogInfo")
	@ResponseBody
	public Map<String,Object> batchDeleteLogInfo(LogInfoVo logInfoVo){
		Map<String, Object> map=new HashMap<>();
		String msg="删除成功";
		try {
			//做删除
			Integer[] ids=logInfoVo.getIds();
			if(null!=ids&&ids.length>0) {
				for (Integer integer : ids) {
					this.logInfoService.deleteLogInfo(integer);
				}
			}
		} catch (Exception e) {
			msg="删除失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
}
