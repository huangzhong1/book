package com.sxt.sys.utils;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ZTreeNode {
	private Integer id;
	//改别名
	@JsonProperty("pId")
	private Integer pid;
	private String name;
	private Boolean isParent;
	private Boolean open;
	private Boolean checked;
	
	private List<ZTreeNode> children=new ArrayList<>();
	
	public ZTreeNode() {
	}
	//单选择树的构造
	public ZTreeNode(Integer id, Integer pid, String name, Boolean isParent, Boolean open) {
		super();
		this.id = id;
		this.pid = pid;
		this.name = name;
		this.isParent = isParent;
		this.open = open;
	}
//多选择树的构造 
	public ZTreeNode(Integer id, Integer pid, String name, Boolean isParent, Boolean open, Boolean checked) {
		super();
		this.id = id;
		this.pid = pid;
		this.name = name;
		this.isParent = isParent;
		this.open = open;
		this.checked = checked;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Boolean getIsParent() {
		return isParent;
	}
	public void setIsParent(Boolean isParent) {
		this.isParent = isParent;
	}
	public Boolean getOpen() {
		return open;
	}
	public void setOpen(Boolean open) {
		this.open = open;
	}

	public Boolean getChecked() {
		return checked;
	}

	public void setChecked(Boolean checked) {
		this.checked = checked;
	}
	public List<ZTreeNode> getChildren() {
		return children;
	}
	public void setChildren(List<ZTreeNode> children) {
		this.children = children;
	}
	
}
