package com.sxt.sys.mapper;

import java.util.List;

import com.sxt.sys.domain.Permission;

public interface PermissionMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Permission record);

    int insertSelective(Permission record);

    Permission selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Permission record);

    int updateByPrimaryKey(Permission record);
    
    List<Permission> queryAllPermissions(Permission record);

    /**
     * 根据角色 ID查询权限
     * @param id
     * @return
     */
	List<Permission> queryPermissionByRoleId(Integer id);

	/**
	 * 根据用户id查询菜单
	 * @param id
	 * @param permissionTypeMenu
	 * @return
	 */
	List<Permission> queryPermissionByUserIdForList(Integer id, String permissionTypeMenu);
}