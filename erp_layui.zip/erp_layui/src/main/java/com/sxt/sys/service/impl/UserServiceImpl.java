package com.sxt.sys.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.sxt.sys.constast.SYS_Constast;
import com.sxt.sys.domain.Role;
import com.sxt.sys.domain.User;
import com.sxt.sys.mapper.RoleMapper;
import com.sxt.sys.mapper.UserMapper;
import com.sxt.sys.service.UserService;
import com.sxt.sys.utils.DataGridView;
import com.sxt.sys.utils.MD5Utils;
import com.sxt.sys.vo.RoleVo;
import com.sxt.sys.vo.UserVo;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserMapper userMapper;
	
	@Autowired
	private RoleMapper roleMapper;

	@Override
	public User queryUserByLoginName(String loginname) {
		return userMapper.queryUserByLoginName(loginname);
	}

	@Override
	public DataGridView queryAllUsers(UserVo userVo) {
		Page<Object> page=PageHelper.startPage(userVo.getPage(), userVo.getLimit());
		List<User> users = this.userMapper.queryAllUsers(userVo);
		DataGridView view=new DataGridView(page.getTotal(), users);
		return view;
	}

	@Override
	public List<User> loadAllUserByDeptId(Integer deptid) {
		return this.userMapper.loadAllUserByDeptId(deptid);
	}
	
	@Override
	public void addUser(UserVo userVo) {
		this.userMapper.insert(userVo);
	}

	@Override
	public User queryUserById(Integer id) {
		return this.userMapper.selectByPrimaryKey(id);
	}

	@Override
	public void updateUser(UserVo userVo) {
		this.userMapper.updateByPrimaryKeySelective(userVo);
	}

	@Override
	public void deleteUser(Integer id) {
		this.userMapper.deleteByPrimaryKey(id);
	}

	@Override
	public void updateUserPwd(UserVo userVo) {
		//查询用户信息
		User user=this.userMapper.selectByPrimaryKey(userVo.getId());
		String salt=user.getName()+user.getAddress();
		Integer hashIterations=2;
		String defalutPwd=MD5Utils.decodePassword(SYS_Constast.USER_DEFAUlLT_PASSWORD, salt, hashIterations);
		user.setPwd(defalutPwd);
		//更新
		this.userMapper.updateByPrimaryKeySelective(user);
	}

	@Override
	public DataGridView loadAllUserRoles(UserVo userVo) {
		//1，查询所有可用的角色
		Role record=new Role();
		record.setAvailable(SYS_Constast.AVAILABLE_YES);
		List<Role> allAvailableRoles = roleMapper.queryAllRoles(record);
		//2，根据用户ID查询当前用户的角色
		List<Role> userRoles=roleMapper.queryRolesByUserId(userVo.getId());
		List<RoleVo> roles=new ArrayList<>();
		for (Role arole : allAvailableRoles) {
			Boolean LAY_CHECKED=false;
			for (Role role : userRoles) {
				if(arole.getId()==role.getId()) {
					LAY_CHECKED=true;
				}
			}
			RoleVo roleVo=new RoleVo();
			//copy属性
			BeanUtils.copyProperties(arole, roleVo);
			roleVo.setLAY_CHECKED(LAY_CHECKED);
			roles.add(roleVo);
		}
		return new DataGridView(Long.valueOf(allAvailableRoles.size()), roles);
	}

	@Override
	public void addUserRoles(UserVo userVo) {
		Integer uid=userVo.getId();
		Integer [] rids=userVo.getIds();
		//1删除原有的用户的角色
		this.userMapper.deleteUserRoleByUserId(uid);
		//2重新分配
		if(rids!=null&&rids.length>0) {
			for (Integer rid : rids) {
				this.userMapper.insertUserRole(uid,rid);
			}
		}
	}

	

}
