package com.sxt.sys.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sxt.sys.constast.SYS_Constast;
import com.sxt.sys.domain.User;
import com.sxt.sys.service.UserService;
import com.sxt.sys.utils.ChineseToPinyinUtils;
import com.sxt.sys.utils.DataGridView;
import com.sxt.sys.utils.MD5Utils;
import com.sxt.sys.vo.UserVo;

@Controller
@RequestMapping("user")
public class UserController {
	
	@Autowired
	private UserService userService;

	/**
	 * 跳转到userManager.jsp
	 */
	@RequestMapping("toUserManager")
	public String toUserManager() {
		return "system/user/userManager";
	}
	
	/**
	 * 跳转到左边部门树
	 */
	@RequestMapping("toUserLeft")
	public String toUserLeft()
	{
		return "system/user/userLeft";
	}
	
	/**
	 * 跳转到右边的用户列表
	 */
	@RequestMapping("toUserRight")
	public String toUserRight()
	{
		return "system/user/userRight";
	}
	
	/**
	 * 加载用户列表
	 */
	@RequestMapping("loadAllUsers")
	@ResponseBody
	public DataGridView loadAllUsers(UserVo userVo) {
		return this.userService.queryAllUsers(userVo);
	}
	
	
	/**
	 * 跳转到添加页面
	 */
	@RequestMapping("toAddUser")
	public String toAddUser() {
		return "system/user/userAdd";
	}
	
	/**
	 * 加载根据部门ID查询用户
	 */
	@RequestMapping("loadAllUserByDeptId")
	@ResponseBody
	public List<User> loadAllUserByDeptId(Integer deptid){
		return this.userService.loadAllUserByDeptId(deptid);
	}
	
	/**
	 * 把用户名改成拼音
	 */
	@RequestMapping("createLoginName")
	@ResponseBody
	public String createLoginName(String name) {
		return ChineseToPinyinUtils.getPingYin(name);
	}
	
	/**
	 * 添加
	 */
	@RequestMapping("addUser")
	@ResponseBody
	public Map<String,Object> addUser(UserVo userVo){
		Map<String, Object> map=new HashMap<>();
		String msg="添加成功";
		try {
			//做添加
			//设置默认密码
			String salt=userVo.getName()+userVo.getAddress();
			userVo.setPwd(MD5Utils.decodePassword(SYS_Constast.USER_DEFAUlLT_PASSWORD, salt, SYS_Constast.USER_HASHITERATIONS));
			//设置默认头像
			userVo.setImgpath(SYS_Constast.USER_DEFALUT_TITLE_IMG);
			//设置type类型
			userVo.setType(SYS_Constast.USER_TYPE_NORMAL);
			this.userService.addUser(userVo);
		} catch (Exception e) {
			msg="添加失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	/**
	 * 跳转到修改页面
	 */
	@RequestMapping("toUpdateUser")
	public String toUpdateUser(UserVo userVo,Model model) {
		User user=this.userService.queryUserById(userVo.getId());
		model.addAttribute("user", user);
		//领导的对象 
		User leaderUser=this.userService.queryUserById(user.getMgr());
		model.addAttribute("leaderUser", leaderUser);
		return "system/user/userUpdate";
	}
	
	/**
	 * 修改
	 */
	@RequestMapping("updateUser")
	@ResponseBody
	public Map<String,Object> updateUser(UserVo userVo){
		Map<String, Object> map=new HashMap<>();
		String msg="修改成功";
		try {
			//做修改
			String salt=userVo.getName()+userVo.getAddress();
			userVo.setPwd(MD5Utils.decodePassword(SYS_Constast.USER_DEFAUlLT_PASSWORD, salt, SYS_Constast.USER_HASHITERATIONS));
			this.userService.updateUser(userVo);
		} catch (Exception e) {
			msg="修改失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	/**
	 * 删除
	 */
	@RequestMapping("deleteUser")
	@ResponseBody
	public Map<String,Object> deleteUser(UserVo userVo){
		Map<String, Object> map=new HashMap<>();
		String msg="删除成功";
		try {
			//做删除
			this.userService.deleteUser(userVo.getId());
		} catch (Exception e) {
			msg="删除失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	/**
	 * 批量删除
	 */
	@RequestMapping("batchDeleteUser")
	@ResponseBody
	public Map<String,Object> batchDeleteUser(UserVo userVo){
		Map<String, Object> map=new HashMap<>();
		String msg="删除成功";
		try {
			//做删除
			Integer[] ids=userVo.getIds();
			if(null!=ids&&ids.length>0) {
				for (Integer integer : ids) {
					this.userService.deleteUser(integer);
				}
			}
		} catch (Exception e) {
			msg="删除失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	/**
	 * 重置密码
	 */
	@RequestMapping("resetPwd")
	@ResponseBody
	public Map<String,Object> resetPwd(UserVo userVo){
		Map<String, Object> map=new HashMap<>();
		String msg="重置成功";
		try {
			//做删除
			this.userService.updateUserPwd(userVo);
		} catch (Exception e) {
			msg="重置失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
	
	
	/**
	 * 跳转到分配角色的页面
	 * 
	 */
	@RequestMapping("toSelectUserRole")
	public String toSelectUserRole(UserVo userVo) {
		return "system/user/selectUserRole";
	}
	
	/**
	 * 查询当前可用的角色并选中用户已拥有的角色
	 */
	@RequestMapping("loadAllUserRoles")
	@ResponseBody
	public DataGridView loadAllUserRoles(UserVo userVo) {
		return this.userService.loadAllUserRoles(userVo);
	}
	
	/**
	 *分配角色
	 */
	@RequestMapping("addUserRoles")
	@ResponseBody
	public Map<String,Object> addUserRoles(UserVo userVo){
		Map<String, Object> map=new HashMap<>();
		String msg="分配成功";
		try {
			this.userService.addUserRoles(userVo);
		} catch (Exception e) {
			msg="分配失败"+e.getMessage();
		}
		map.put("msg", msg);
		return map;
	}
}
