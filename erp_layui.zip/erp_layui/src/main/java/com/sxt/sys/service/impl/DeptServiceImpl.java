package com.sxt.sys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.sxt.sys.domain.Dept;
import com.sxt.sys.mapper.DeptMapper;
import com.sxt.sys.service.DeptService;
import com.sxt.sys.utils.DataGridView;
import com.sxt.sys.vo.DeptVo;

@Service
public class DeptServiceImpl implements DeptService {

	@Autowired
	private DeptMapper deptMapper;
	
	@Override
	public List<Dept> queryAllDeptForList(DeptVo deptVo) {
		return deptMapper.queryAllDept(deptVo);
	}

	@Override
	public DataGridView queryAllDepts(DeptVo deptVo) {
		Page<Object> page=PageHelper.startPage(deptVo.getPage(), deptVo.getLimit());
		List<Dept> data=this.deptMapper.queryAllDept(deptVo);
		DataGridView view=new DataGridView(page.getTotal(), data);
		return view;
	}

	/**
	 * 添加部门
	 */
	@Override
	public void addDept(DeptVo deptVo) {
		this.deptMapper.insert(deptVo);
	}

	@Override
	public Dept queryDeptById(Integer id) {
		
		return this.deptMapper.selectByPrimaryKey(id);
	}

	@Override
	public void updateDept(DeptVo deptVo) {
		this.deptMapper.updateByPrimaryKey(deptVo);
	}

	@Override
	public void deleteDept(Integer id) {
		this.deptMapper.deleteByPrimaryKey(id);
	}

}
