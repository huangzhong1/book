package com.sxt.sys.service;

import java.util.List;

import com.sxt.sys.domain.User;
import com.sxt.sys.utils.DataGridView;
import com.sxt.sys.vo.UserVo;

public interface UserService {
	 /**
     * 根据登陆名查询用户
     */
    User queryUserByLoginName(String loginname);
    
    /**
	 * 查询所有用户返回DataGridView
	 */
	public DataGridView queryAllUsers(UserVo userVo);

	/**
	 * 加载根据部门ID查询用户
	 * @param deptid
	 * @return
	 */
	List<User> loadAllUserByDeptId(Integer deptid);
	/**
	 * 添加用户
	 * @param userVo
	 */
	public void addUser(UserVo userVo);

	/**
	 * 根据ID查询用户
	 * @param id
	 * @return
	 */
	public User queryUserById(Integer id);

	/**
	 * 修改用户信息
	 * @param userVo
	 */
	public void updateUser(UserVo userVo);

	/**
	 * 删除
	 * @param userVo
	 */
	public void deleteUser(Integer id);

	/**
	 * 重置密码
	 * @param userVo
	 */
	void updateUserPwd(UserVo userVo);

	/**
	 * 查询当前可用的角色并选中用户已拥有的角色
	 * @param userVo
	 * @return
	 */
	DataGridView loadAllUserRoles(UserVo userVo);
/**
 * 分配角色
 * @param userVo
 */
	void addUserRoles(UserVo userVo);


}
