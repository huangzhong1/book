package com.sxt.sys.service;

import java.util.List;

import com.sxt.sys.domain.Permission;
import com.sxt.sys.utils.DataGridView;
import com.sxt.sys.vo.PermissionVo;

public interface PermissionService {
	
	/**
	 * 查询所有的权限返回List<Permission>
	 */
	public List<Permission> queryAllPermissionForList(PermissionVo permissionVo);
	
	/**
	 * 查询所有权限返回DataGridView
	 */
	public DataGridView queryAllPermissions(PermissionVo permissionVo);

	/**
	 * 添加权限
	 * @param permissionVo
	 */
	public void addPermission(PermissionVo permissionVo);

	/**
	 * 根据ID查询权限
	 * @param id
	 * @return
	 */
	public Permission queryPermissionById(Integer id);

	/**
	 * 修改权限信息
	 * @param permissionVo
	 */
	public void updatePermission(PermissionVo permissionVo);

	/**
	 * 删除
	 * @param permissionVo
	 */
	public void deletePermission(Integer id);

	/**
	 * 根据角色ID查询权限
	 * @param id
	 * @return
	 */
	public List<Permission> queryPermissionByRoleIdForList(Integer id);

	/**
	 * //根据用户id查询菜单
	 * @param id
	 * @param permissionTypeMenu
	 * @return
	 */
	public List<Permission> queryPermissionByUserIdForList(Integer id, String permissionTypeMenu);
}
