package com.sxt.sys.utils;

import org.apache.shiro.crypto.hash.Md5Hash;

public class MD5Utils {

	/**
	 * @param source原始密码
	 * @param salt  盐
	 * @param hashIterations  散列次数
	 * @return
	 */
	public static String decodePassword(String source,String salt,Integer hashIterations) {
		String password=new Md5Hash(source, salt, hashIterations).toString();
		return password;
	}
}